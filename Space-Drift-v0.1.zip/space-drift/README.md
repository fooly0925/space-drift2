# Space Drift v0.1

A small native Android prototype. All art is drawn on the device: no downloaded assets, ads, accounts, internet permission, or gameplay dependencies. Requires Android 6 or newer. Portrait play uses a 9:16 field, with margins on taller screens. Sound is not implemented yet.

## Play

Tap **Let's drift!**, then touch and drag anywhere in the playfield. The ship smoothly follows about 55 game units above your finger. Release to hold position. Catch yellow stars and avoid asteroids, fast comets, rotating drifting junk, and slow swaying UFOs. Each collected star speeds up obstacles a little. The top bar shows distance toward your destination, with a ship and planet at its ends.

Stage 1 is a 30-second journey; subsequent journeys add 10 seconds each. Ship Speed rewards improve steering response, not journey duration. Hits remove 20 fuel percentage points and grant 1.25 seconds of protection. Fuel reaching zero takes priority over the sixth-hit destruction. Outcomes animate for 2.6 seconds before the next screen. Tap the pause control at the upper right; switching apps also pauses.

Arrive to choose **Ship Speed +5%** or **Fuel Tank +5%**, multiplied into the current run. Failure shows the reached planet, attempted stage, total stars, distance, and best planet. **Try Again** starts Stage 1 with upgrades reset. Only best planet is saved on the device. Permanent progression is deliberately deferred.

## Get an APK using only an Android phone (cloud build)

The files in this folder are the complete project source, not an already-built APK. This environment could write files but could not start its command runner, so compilation and the included tests have **not been run**. The workflow below runs the tests before making an APK. A successful build does not replace a device playtest.

1. Sign in to GitHub in your phone browser and create an empty repository named `space-drift`. A private repository is fine. If file uploading is awkward, turn on your browser's **Desktop site** option.
2. Upload **the contents of this folder** to the repository root. The root must contain `settings.gradle`, `build.gradle`, `app/`, and `.github/`. Preserve all subfolders. The `.github` folder may be hidden in a file picker; if so, use GitHub's **Add file → Create new file** and create `.github/workflows/android.yml`, copying its exact contents from this project. A trusted helper can upload the folder for you if your phone's picker cannot preserve directories.
3. In the repository, open **Actions → Build Space Drift APK → Run workflow**. If prompted, enable Actions. Wait for the run to show a green check. A red cross means the build or tests failed; open the failed step to see the reason.
4. Open the successful run and download **Space-Drift-v0.1-APK** under **Artifacts**. This downloads a ZIP. Extract it with your phone's Files app to find `app-debug.apk`.
5. Tap `app-debug.apk`. Android may ask you to allow installations from your browser or Files app. Allow that app for this installation, then tap **Install**. You can switch that permission off afterward.
6. Open **Space Drift v0.1**. Switch to airplane mode to confirm fully offline play.

Internet is needed to obtain/build the APK, but never to play. This is a debug APK for personal prototype testing. Each cloud run may use a new debug signing key: if Android refuses an update because signatures differ, uninstall the previous prototype and install again. Uninstalling erases its best-planet record. Store publishing and permanent release signing are not configured.

## Build on a computer

Install Android Studio and open this folder as a project. Use Java 17, Android SDK 35, and Gradle 8.11.1 with Android Gradle Plugin 8.9.2. This source delivery does not contain a binary Gradle wrapper; with Gradle 8.11.1 installed, run `gradle wrapper --gradle-version 8.11.1` once to generate it. Then sync the project and use Android Studio's Build menu to generate a debug APK. The output is `app/build/outputs/apk/debug/app-debug.apk`.

With an installed Gradle 8.11.1, the command `gradle :app:testDebugUnitTest :app:assembleDebug` runs the tests and builds the APK. With the generated wrapper, use `gradlew.bat` on Windows or `./gradlew` on macOS/Linux instead of `gradle`. Transfer the APK to your phone and follow steps 5–6 above.

Official build guidance: https://developer.android.com/build/building-cmdline

## Fuel rules and implementation notes

Fuel is stored in actual units; the HUD shows a percentage of upgraded capacity. Capacity is `100 × tank multiplier`. Each stage starts with `30 × tank multiplier` fuel. The journey consumes 95 units regardless of upgrades. The available star count is `ceil(stage duration / 2.5) × 5`; each collected star adds `70 × tank multiplier / (0.6 × available stars)`, capped at tank capacity. Arrival requires 5 actual fuel units.

At baseline, evenly collecting exactly 60% gives `30 + 70 − 95 = 5`, enough to arrive. A 5% tank upgrade gives `31.5 + 73.5 − 95 = 10`, making it useful in later stages. Timing matters: a long gap can run you dry and pickups at a full tank are wasted. Collisions add further fuel demand. Stars spawn throughout the journey, with the last appearing three seconds before arrival so it can reach the ship's play area. Steering upgrades do not alter burn, star supply, or journey length.

Code: `Rules.java` owns stage/fuel/reward rules; `DriftView.java` owns drawing, spawning, input, hit protection, and animation; `MainActivity.java` handles Android lifecycle. Best planet uses a separate local preferences store, leaving room for a future permanent progression system. No permanent unlocks are implemented.

## Verification status and first device check

Nine JUnit tests are included for travel durations, the 60% baseline across stages, insufficient arrival fuel, tank benefits, collision percentage points, both sixth-hit priorities, frozen failure statistics, and run reset. **They are authored but unexecuted locally.** GitHub Actions runs them and uploads the report. No APK is supplied or claimed to have passed device testing.

On the first device, check drag responsiveness, HUD visibility on a tall screen, pausing on app switches, fuel failure, repeated collisions, both rewards, Stage 2 progression, and best-planet persistence after closing/reopening. Procedural random pickup placement and obstacle density still need real playtesting for difficulty. This prototype has no audio, haptics, tutorial sequence, or final accessibility pass.

Later visual choices to discuss: spaceship character, planet themes, obstacle personalities, HUD styling, and sound. The current pastel smiling rocket is a placeholder so those choices can be made after playing.
