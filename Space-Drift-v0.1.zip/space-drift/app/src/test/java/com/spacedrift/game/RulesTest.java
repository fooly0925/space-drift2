package com.spacedrift.game;

import org.junit.Test;
import static org.junit.Assert.*;

public class RulesTest {
    private Rules fresh() { Rules r = new Rules(); r.restart(); return r; }
    private Rules complete(int stage, double fraction, double tank) {
        Rules r = fresh(); r.stage = stage; r.tank = tank; r.beginStage();
        int count = (int)Math.round(r.availableStars() * fraction);
        double interval = r.duration() / count;
        r.advance(interval / 2);
        for (int i = 0; i < count; i++) {
            r.collect(); r.advance(i == count - 1 ? interval / 2 : interval);
        }
        return r;
    }
    @Test public void journeysLengthenByTenSeconds() {
        Rules r = fresh(); assertEquals(30, r.duration(), 0);
        r.stage = 2; assertEquals(40, r.duration(), 0);
        r.stage = 10; assertEquals(120, r.duration(), 0);
    }
    @Test public void sixtyPercentArrivesAcrossStages() {
        for (int s : new int[]{1, 2, 5, 12}) {
            Rules r = complete(s, .6, 1);
            assertEquals(Rules.State.ARRIVED, r.state);
            assertEquals(5, r.fuel, 1e-7);
            assertEquals(s + 1, r.bestPlanet);
        }
    }
    @Test public void insufficientReserveFails() {
        assertEquals(Rules.State.OUT_OF_FUEL, complete(1, .5, 1).state);
    }
    @Test public void tankUpgradeIncreasesArrivalFuel() {
        Rules base = complete(1, .6, 1), upgraded = complete(1, .6, 1.05);
        assertTrue(upgraded.fuel > base.fuel);
        assertEquals(10, upgraded.fuel, 1e-7);
    }
    @Test public void collisionSubtractsTwentyPointsWithUpgrade() {
        Rules r = fresh(); r.tank = 1.4; r.fuel = r.capacity() * .8;
        r.hit(); assertEquals(60, r.percent(), 1e-8);
    }
    @Test public void zeroFuelWinsOverSixthCollision() {
        Rules r = fresh(); r.hits = 5; r.fuel = 20; r.hit();
        assertEquals(Rules.State.OUT_OF_FUEL, r.state);
    }
    @Test public void sixthCollisionWithFuelDestroysShip() {
        Rules r = fresh(); r.hits = 5; r.fuel = 80; r.hit();
        assertEquals(Rules.State.DESTROYED, r.state);
    }
    @Test public void dryFlightStopsImmediatelyAndFreezesStats() {
        Rules r = fresh(); r.fuel = .01; r.advance(.1);
        assertEquals(Rules.State.OUT_OF_FUEL, r.state);
        double distance = r.runDistance; r.collect(); r.hit(); r.advance(10);
        assertEquals(distance, r.runDistance, 0); assertEquals(0, r.runStars);
    }
    @Test public void rewardsAndRestartKeepOnlyBestPlanet() {
        Rules r = complete(1, .6, 1); r.reward(true);
        assertEquals(2, r.stage); assertEquals(1.05, r.speed, 1e-9);
        r.state = Rules.State.ARRIVED; r.reward(false);
        assertEquals(1.05, r.tank, 1e-9);
        r.restart(); assertEquals(1, r.stage); assertEquals(1, r.speed, 0);
        assertEquals(1, r.tank, 0); assertEquals(0, r.runStars); assertEquals(2, r.bestPlanet);
    }
}
