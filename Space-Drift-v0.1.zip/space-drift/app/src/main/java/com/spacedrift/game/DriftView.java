package com.spacedrift.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Random;

/** Fixed 360x640 playfield letterboxed on all devices; all artwork is procedural. */
public final class DriftView extends View {
    private final Rules rules = new Rules();
    private final Paint paint = new Paint(3);
    private final Random random = new Random();
    private final ArrayList<Body> bodies = new ArrayList<>();
    private final SharedPreferences prefs;
    private float scale = 1, left, top, x = 180, y = 500, tx = 180, ty = 500;
    private double spawnClock, animation, invulnerable, scenery;
    private int spawned, pointer = -1;
    private long last;
    private boolean suspended, paused, started, results, reward;
    private static final class Body {
        double x, y, origin, age, velocity;
        int kind;
        Body(double px, int k, double v) { x = origin = px; y = -30; kind = k; velocity = v; }
    }
    public DriftView(Context context) {
        super(context);
        prefs = context.getSharedPreferences("space-drift-records", Context.MODE_PRIVATE);
        rules.bestPlanet = prefs.getInt("bestPlanet", 1);
        rules.restart();
        setContentDescription("Space Drift. Drag to steer. Stars refill fuel. Avoid space objects.");
    }
    public void suspend() { suspended = true; pointer = -1; if (started && !results && !reward) paused = true; }
    public void resume() { suspended = false; last = 0; invalidate(); }
    private void resetField() {
        bodies.clear(); spawned = 0; spawnClock = 0; animation = 0;
        invulnerable = 0; x = tx = 180; y = ty = 500;
        pointer = -1; results = reward = paused = false; last = 0;
    }
    private void tick(double dt) {
        if (paused || !started || results || reward) return;
        scenery += dt;
        if (rules.state != Rules.State.PLAYING) {
            animation += dt;
            for (Body b : bodies) b.y += b.velocity * dt;
            if (rules.state == Rules.State.OUT_OF_FUEL) { y -= dt * 13; x += dt * 5; }
            if (rules.state == Rules.State.ARRIVED) y -= dt * 85;
            if (animation >= 2.6) {
                if (rules.state == Rules.State.ARRIVED) {
                    reward = true;
                    prefs.edit().putInt("bestPlanet", rules.bestPlanet).apply();
                } else results = true;
            }
            return;
        }
        invulnerable = Math.max(0, invulnerable - dt);
        double blend = 1 - Math.exp(-8 * rules.speed * dt);
        x += (tx - x) * blend; y += (ty - y) * blend;
        // Every scheduled star can cross the ship area before the journey ends.
        double endSpawn = rules.duration() - 3;
        while (spawned < rules.availableStars() && rules.elapsed >= spawned * endSpawn / rules.availableStars()) {
            bodies.add(new Body(30 + random.nextInt(300), 0, 235)); spawned++;
        }
        spawnClock -= dt;
        if (spawnClock <= 0 && rules.elapsed < rules.duration() - 2) {
            int kind = 1 + random.nextInt(4);
            double[] speeds = {235, 130, 215, 155, 100};
            bodies.add(new Body(35 + random.nextInt(290), kind, speeds[kind]));
            spawnClock = Math.max(0.48, 1.0 - rules.stage * 0.025) + random.nextDouble() * 0.35;
        }
        double acceleration = 1 + 0.9 * rules.stars / rules.availableStars();
        for (int i = bodies.size() - 1; i >= 0; i--) {
            Body b = bodies.get(i);
            b.age += dt;
            b.y += b.velocity * dt * (b.kind == 0 ? 1 : acceleration);
            if (b.kind == 3) b.x = b.origin + Math.sin(b.age * 1.7) * 26;
            if (b.kind == 4) b.x = b.origin + Math.sin(b.age * 2.2) * 40;
            double radius = b.kind == 0 ? 23 : 28;
            if (Math.hypot(b.x - x, b.y - y) < radius) {
                if (b.kind == 0) { rules.collect(); bodies.remove(i); }
                else if (invulnerable <= 0) { rules.hit(); invulnerable = 1.25; bodies.remove(i); }
                if (rules.state != Rules.State.PLAYING) break;
            } else if (b.y > 690) bodies.remove(i);
        }
        rules.advance(dt);
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = System.nanoTime();
        double dt = last == 0 ? 0 : Math.min(0.05, (now - last) / 1e9);
        last = now;
        if (!suspended) tick(dt);
        canvas.drawColor(Color.rgb(9, 13, 32));
        scale = Math.min(getWidth() / 360f, getHeight() / 640f);
        left = (getWidth() - 360 * scale) / 2; top = (getHeight() - 640 * scale) / 2;
        canvas.save(); canvas.translate(left, top); canvas.scale(scale, scale);
        canvas.clipRect(0, 0, 360, 640);
        paint.setShader(new LinearGradient(0, 0, 360, 640, Color.rgb(24, 29, 64), Color.rgb(52, 24, 76), Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, 360, 640, paint); paint.setShader(null);
        for (int i = 0; i < 65; i++) {
            float sy = (float)((i * 97 + scenery * (12 + i % 3 * 8)) % 640);
            circle(canvas, (i * 71) % 360, sy, i % 4 == 0 ? 1.7f : 0.8f, 0xffb9b3dd);
        }
        for (Body b : bodies) drawBody(canvas, b);
        if (rules.state == Rules.State.ARRIVED && !reward) planet(canvas, 250, 200, 72);
        if (rules.state == Rules.State.DESTROYED && animation > 0) {
            for (int i = 0; i < 14; i++) {
                double a = i * Math.PI * 2 / 14;
                circle(canvas, x + (float)(Math.cos(a) * animation * 65), y + (float)(Math.sin(a) * animation * 65),
                    (float)Math.max(1, 7 - animation * 2), i % 2 == 0 ? 0xffffcba4 : 0xffcab5ff);
            }
        } else {
            canvas.save(); canvas.translate(x, y);
            if (rules.state == Rules.State.OUT_OF_FUEL) canvas.rotate((float)(animation * 18));
            if (invulnerable <= 0 || ((int)(scenery * 12)) % 2 == 0)
                ship(canvas, 0, 0, 1, rules.state == Rules.State.PLAYING || (animation < 0.7 && ((int)(animation * 16)) % 2 == 0));
            canvas.restore();
        }
        hud(canvas);
        if (!started) {
            panel(canvas, "SPACE DRIFT", "A little ship. A big journey.");
            text(canvas, "Drag anywhere to steer", 180, 295, 19, 0xffffffff);
            text(canvas, "Stars are fuel. Dodge space objects.", 180, 326, 14, 0xffd2cce5);
            text(canvas, "Collect 60% to reach your next planet", 180, 351, 14, 0xffd2cce5);
            button(canvas, 115, 397, 245, 452, "Let's drift!");
            text(canvas, "v0.1 • offline • temporary run upgrades", 180, 482, 12, 0xffb9b3dd);
        } else if (paused) {
            panel(canvas, "PAUSED", "Your journey is waiting");
            button(canvas, 85, 360, 275, 418, "Continue");
        } else if (reward) {
            panel(canvas, "HELLO, PLANET " + (rules.stage + 1), "Choose a gift for this run");
            text(canvas, "Stars: " + rules.stars + " / " + rules.availableStars(), 180, 294, 17, 0xffffdf8e);
            button(canvas, 45, 335, 315, 391, "Ship Speed +5%");
            button(canvas, 45, 408, 315, 464, "Fuel Tank +5%");
        } else if (results) {
            panel(canvas, rules.state == Rules.State.DESTROYED ? "SHIP DESTROYED" : "OUT OF FUEL", "Every drift is a new adventure");
            text(canvas, "Planet reached: " + rules.stage, 180, 292, 17, 0xffffffff);
            text(canvas, "Journey attempted: Stage " + rules.stage, 180, 322, 16, 0xffd2cce5);
            text(canvas, "Stars collected: " + rules.runStars, 180, 352, 17, 0xffffdf8e);
            text(canvas, "Distance: " + Math.round(rules.runDistance) + " units", 180, 382, 17, 0xffffffff);
            text(canvas, "Best planet: " + rules.bestPlanet, 180, 412, 17, 0xffc8baff);
            button(canvas, 85, 442, 275, 497, "Try Again");
        } else if (rules.state != Rules.State.PLAYING) {
            if (rules.state == Rules.State.OUT_OF_FUEL) {
                paint.setColor(Color.argb((int)(Math.min(1, animation / 2.6) * 100), 0, 0, 20));
                canvas.drawRect(0, 0, 360, 640, paint);
            }
            text(canvas, rules.state == Rules.State.ARRIVED ? "Made it!" : rules.state == Rules.State.DESTROYED ? "SHIP DESTROYED" : "OUT OF FUEL", 180, 315, 25, 0xffffffff);
        }
        canvas.restore();
        if (!suspended) postInvalidateOnAnimation();
    }
    private void hud(Canvas c) {
        round(c, 10, 8, 350, 101, 14, 0xdd171a39);
        ship(c, 28, 29, 0.45f, false); planet(c, 330, 29, 12);
        round(c, 50, 24, 310, 34, 5, 0xff41435f);
        round(c, 50, 24, 50 + (float)rules.progress() * 260, 34, 5, 0xffbcb3ff);
        text(c, "Journey to Planet " + (rules.stage + 1), 180, 54, 13, 0xffece4ff);
        text(c, "Fuel " + Math.round(rules.percent()) + "%", 62, 79, 14, 0xffffdd85);
        text(c, "Stars " + rules.stars + "/" + rules.availableStars(), 185, 79, 13, 0xffece4ff);
        text(c, "Hits " + rules.hits + "/6", 291, 79, 13, 0xfff3b8cc);
        round(c, 22, 87, 335, 93, 3, 0xff454058);
        round(c, 22, 87, 22 + (float)(rules.percent() / 100) * 313, 93, 3, 0xffffcf78);
        if (started && !results && !reward && rules.state == Rules.State.PLAYING)
            text(c, "Ⅱ", 336, 125, 22, 0xffffffff);
    }
    private void drawBody(Canvas c, Body b) {
        float bx = (float)b.x, by = (float)b.y;
        c.save(); c.translate(bx, by);
        if (b.kind == 0) {
            Path p = new Path();
            for (int i = 0; i < 10; i++) {
                double a = -Math.PI / 2 + i * Math.PI / 5;
                float r = i % 2 == 0 ? 10 : 5;
                float px = (float)Math.cos(a) * r, py = (float)Math.sin(a) * r;
                if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
            }
            p.close(); paint.setColor(0xffffd976); c.drawPath(p, paint);
        } else if (b.kind == 1) {
            circle(c, 0, 0, 17, 0xffbca7be); circle(c, -5, -5, 5, 0xff8b799c); circle(c, 7, 6, 4, 0xff8b799c);
        } else if (b.kind == 2) {
            Path tail = new Path(); tail.moveTo(-11, 0); tail.lineTo(0, -55); tail.lineTo(11, 0); tail.close();
            paint.setColor(0x8899eaff); c.drawPath(tail, paint); circle(c, 0, 0, 12, 0xffa0edff);
        } else if (b.kind == 3) {
            c.rotate((float)b.age * 100);
            round(c, -23, -7, 23, 7, 3, 0xffb4b9ee); round(c, -8, -13, 8, 13, 4, 0xffe5ccae);
            round(c, -21, -5, -11, 5, 1, 0xff6865a0); round(c, 11, -5, 21, 5, 1, 0xff6865a0);
        } else {
            circle(c, 0, -5, 12, 0xffb3efcf);
            round(c, -22, -1, 22, 10, 8, 0xffc8a7ff);
            circle(c, -4, -6, 2, 0xff3a3b62); circle(c, 4, -6, 2, 0xff3a3b62);
        }
        c.restore();
    }
    private void ship(Canvas c, float sx, float sy, float size, boolean engine) {
        c.save(); c.translate(sx, sy); c.scale(size, size);
        if (engine) {
            circle(c, 0, 22, 8 + (float)Math.sin(scenery * 28) * 3, 0xffffd17f);
            circle(c, 0, 18, 5, 0xfffff2be);
        }
        Path fins = new Path(); fins.moveTo(-10, -3); fins.lineTo(-23, 17); fins.lineTo(23, 17); fins.lineTo(10, -3); fins.close();
        paint.setColor(0xffe79caf); c.drawPath(fins, paint);
        round(c, -12, -24, 12, 20, 13, 0xfff6e8e3);
        circle(c, 0, -7, 9, 0xff8bcbdc); circle(c, -3, -8, 1.8f, 0xff243c5b); circle(c, 3, -8, 1.8f, 0xff243c5b);
        round(c, -3, -3, 3, -1, 1, 0xff3a6680); c.restore();
    }
    private void planet(Canvas c, float px, float py, float r) {
        circle(c, px, py, r, rules.stage % 2 == 0 ? 0xffb4dcb6 : 0xffd9a9e7);
        circle(c, px - r * 0.3f, py - r * 0.25f, r * 0.22f, 0x557c649f);
        circle(c, px + r * 0.35f, py + r * 0.3f, r * 0.17f, 0x557c649f);
    }
    private void circle(Canvas c, float px, float py, float r, int color) { paint.setColor(color); c.drawCircle(px, py, r, paint); }
    private void round(Canvas c, float l, float t, float r, float b, float radius, int color) {
        paint.setColor(color); c.drawRoundRect(l, t, r, b, radius, radius, paint);
    }
    private void text(Canvas c, String value, float px, float py, float size, int color) {
        paint.setColor(color); paint.setTextSize(size); paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER); c.drawText(value, px, py, paint);
    }
    private void panel(Canvas c, String title, String subtitle) {
        round(c, 0, 0, 360, 640, 0, 0xaa090d20);
        round(c, 20, 183, 340, 530, 24, 0xff282645);
        text(c, title, 180, 233, 23, 0xfff5eaff); text(c, subtitle, 180, 262, 14, 0xffc9c0dd);
    }
    private void button(Canvas c, float l, float t, float r, float b, String label) {
        round(c, l, t, r, b, 17, 0xffbfb2fa); text(c, label, (l + r) / 2, (t + b) / 2 + 6, 18, 0xff29233f);
    }
    private boolean inside(float px, float py, float l, float t, float r, float b) { return px >= l && px <= r && py >= t && py <= b; }
    @Override public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            float px = (e.getX() - left) / scale, py = (e.getY() - top) / scale;
            if (!inside(px, py, 0, 0, 360, 640)) return true;
            if (!started) {
                if (inside(px, py, 115, 397, 245, 452)) { started = true; resetField(); }
            } else if (paused) {
                if (inside(px, py, 85, 360, 275, 418)) { paused = false; last = 0; }
            } else if (results) {
                if (inside(px, py, 85, 442, 275, 497)) { rules.restart(); resetField(); }
            } else if (reward) {
                if (inside(px, py, 45, 335, 315, 391)) { rules.reward(true); resetField(); }
                else if (inside(px, py, 45, 408, 315, 464)) { rules.reward(false); resetField(); }
            } else if (rules.state == Rules.State.PLAYING) {
                if (inside(px, py, 315, 102, 360, 148)) { paused = true; }
                else { pointer = e.getPointerId(0); target(px, py); }
            }
            performClick(); return true;
        }
        if (action == MotionEvent.ACTION_MOVE && pointer >= 0 && !paused && rules.state == Rules.State.PLAYING) {
            int index = e.findPointerIndex(pointer);
            if (index >= 0) target((e.getX(index) - left) / scale, (e.getY(index) - top) / scale);
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL ||
            (action == MotionEvent.ACTION_POINTER_UP && e.getPointerId(e.getActionIndex()) == pointer)) pointer = -1;
        return true;
    }
    private void target(float px, float py) { tx = Math.max(24, Math.min(336, px)); ty = Math.max(160, Math.min(575, py - 55)); }
    @Override public boolean performClick() { super.performClick(); return true; }
}
