package com.spacedrift.game;

/** Pure Java run rules, independent of rendering and Android. */
public final class Rules {
    public enum State { PLAYING, OUT_OF_FUEL, DESTROYED, ARRIVED }
    public int stage = 1, hits, stars, runStars, bestPlanet = 1;
    public double speed = 1, tank = 1, fuel, elapsed, runDistance;
    public State state;
    public double duration() { return 30 + 10.0 * (stage - 1); }
    // Multiples of five make 60% an exact whole-star target.
    public int availableStars() { return (int)Math.ceil(duration() / 2.5) * 5; }
    public double capacity() { return 100 * tank; }
    public double percent() { return 100 * fuel / capacity(); }
    public double progress() { return Math.min(1, elapsed / duration()); }
    public void beginStage() { hits = stars = 0; elapsed = 0; fuel = 30 * tank; state = State.PLAYING; }
    public void restart() { stage = 1; speed = tank = 1; runStars = 0; runDistance = 0; beginStage(); }
    public void collect() {
        if (state != State.PLAYING) return;
        stars++; runStars++;
        fuel = Math.min(capacity(), fuel + 70 * tank / (0.6 * availableStars()));
    }
    public void hit() {
        if (state != State.PLAYING) return;
        hits++;
        fuel = Math.max(0, fuel - 0.2 * capacity());
        if (fuel <= 1e-9) state = State.OUT_OF_FUEL;
        else if (hits >= 6) state = State.DESTROYED;
    }
    public void advance(double dt) {
        if (state != State.PLAYING || dt <= 0) return;
        double step = Math.min(dt, duration() - elapsed);
        elapsed += step;
        runDistance += step * 100; // journey units, independent of steering upgrades
        fuel = Math.max(0, fuel - 95 * step / duration());
        if (fuel <= 1e-9) state = State.OUT_OF_FUEL;
        else if (elapsed >= duration() - 1e-9) {
            state = fuel >= 5 - 1e-8 ? State.ARRIVED : State.OUT_OF_FUEL;
            if (state == State.ARRIVED) bestPlanet = Math.max(bestPlanet, stage + 1);
        }
    }
    public void reward(boolean chooseSpeed) {
        if (state != State.ARRIVED) return;
        if (chooseSpeed) speed *= 1.05; else tank *= 1.05;
        stage++; beginStage();
    }
}
